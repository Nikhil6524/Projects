import time
from typing import Iterator
from scapy.all import sniff, Ether

import netprotocols

class Decoder:
    def __init__(self, interface: str):
        """Decode Ethernet frames incoming from a given interface.

        :param interface: Interface from which frames will be captured
            and decoded.
        """
        self.interface = interface
        self.data = None
        self.protocol_queue = ["Ethernet"]
        self.packet_num: int = 0
        self.frame_length: int = 0
        self.epoch_time: float = 0

    def _attach_protocols(self, packet: Ether):
        """Dynamically attach protocols as instance attributes.

        A given packet containing Ethernet, IP, and TCP protocols, for
        example, will be decoded, and the present instance will contain
        the attributes self.ethernet, self.ip, and self.tcp, all of which
        are instances of netprotocols.Protocol.

        :param packet: A Scapy Ether packet object.
        """
        for proto in self.protocol_queue:
            proto_class = getattr(netprotocols, proto, None)
            if proto_class:
                protocol = proto_class(packet)
                setattr(self, proto.lower(), protocol)
                if protocol.encapsulated_proto in (None, "undefined"):
                    break
                self.protocol_queue.append(protocol.encapsulated_proto)

        # Extract raw payload data
        self.data = bytes(packet.payload)

    def execute(self) -> Iterator:
        for packet in sniff(iface=self.interface, count=0, store=False):
            self.packet_num += 1
            self.frame_length = len(packet)
            self.epoch_time = time.time()
            self._attach_protocols(packet)
            yield self
            del self.protocol_queue[1:]

class PacketSniffer:
    def __init__(self):
        """Monitor a network interface for incoming data, decode it and
        send to pre-defined output methods."""
        self._observers = list()

    def register(self, observer) -> None:
        """Register an observer for processing/output of decoded
        frames.

        :param observer: Any object that implements the interface
        defined by the Output abstract base-class."""
        self._observers.append(observer)

    def _notify_all(self, *args, **kwargs) -> None:
        """Send a decoded frame to all registered observers for further
        processing/output."""
        [observer.update(*args, **kwargs) for observer in self._observers]

    def listen(self, interface: str) -> Iterator:
        """Directly output a captured Ethernet frame while
        simultaneously notifying all registered observers, if any.

        :param interface: Interface from which a given frame will be
            captured and decoded.
        """
        for frame in Decoder(interface).execute():
            self._notify_all(frame)
            yield frame

# Example usage:
sniffer = PacketSniffer()
sniffer.listen("your_network_interface")
