import argparse
from scapy.all import sniff, Ether

def packet_callback(packet):
    if Ether in packet:
        # Print information about the Ethernet frame
        print(packet.show())

def main(interface):
    print("[>>>] Packet Sniffer initialized. Waiting for incoming data. Press Ctrl-C to abort...")

    try:
        # Capture packets on the specified interface
        sniff(iface=interface, prn=packet_callback, store=False)
    except KeyboardInterrupt:
        print("[!] Aborting packet capture...")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Network packet sniffer")
    parser.add_argument(
        "-i", "--interface",
        type=str,
        default=None,
        help="Interface from which Ethernet frames will be captured (monitors all available interfaces by default)."
    )
    args = parser.parse_args()

    main(args.interface)
